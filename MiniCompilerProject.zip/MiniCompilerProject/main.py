import tkinter as tk
from tkinter import ttk, messagebox
import re

# Mini language grammar:
# program     -> statement*
# statement   -> "let" IDENT "=" expression ";"
#             | IDENT "=" expression ";"
#             | "print" expression ";"
# expression  -> comparison
# comparison  -> addition (("<" | ">" | "==" | "!=") addition)?
# addition    -> multiplication (("+" | "-") multiplication)*
# multiplication -> unary (("*" | "/") unary)*
# unary       -> ("+" | "-") unary | primary
# primary     -> NUMBER | IDENT | "(" expression ")"

TOKEN_RE = re.compile(
    r"(?P<SPACE>\s+)|(?P<NUMBER>\d+(?:\.\d+)?)|"
    r"(?P<IDENT>[A-Za-z_][A-Za-z0-9_]*)|"
    r"(?P<OP>==|!=|[+\-*/=<>;()])|(?P<MISMATCH>.)"
)

class CompileError(Exception):
    pass

def tokenize(source):
    tokens = []
    for match in TOKEN_RE.finditer(source):
        kind = match.lastgroup
        value = match.group()
        if kind == "SPACE":
            continue
        if kind == "MISMATCH":
            raise CompileError(f"Lexical Error: Unexpected character {value!r} at position {match.start()}.")
        if kind == "IDENT" and value in ("let", "print"):
            kind = "KEYWORD"
        tokens.append((kind, value, match.start()))
    tokens.append(("EOF", "", len(source)))
    return tokens

class Parser:
    def __init__(self, tokens):
        self.tokens = tokens
        self.pos = 0

    def current(self):
        return self.tokens[self.pos]

    def accept(self, value=None, kind=None):
        tok = self.current()
        if (value is None or tok[1] == value) and (kind is None or tok[0] == kind):
            self.pos += 1
            return tok
        return None

    def expect(self, value=None, kind=None, message="Unexpected token"):
        tok = self.accept(value, kind)
        if tok is None:
            got = self.current()[1] or "end of input"
            raise CompileError(f"Syntax Error: {message}; found {got!r}.")
        return tok

    def parse(self):
        statements = []
        while self.current()[0] != "EOF":
            statements.append(self.statement())
        return ("program", statements)

    def statement(self):
        if self.accept("let"):
            name = self.expect(kind="IDENT", message="Expected variable name")[1]
            self.expect("=", message="Expected '=' after variable name")
            expr = self.expression()
            self.expect(";", message="Expected ';' at end of declaration")
            return ("let", name, expr)
        if self.accept("print"):
            expr = self.expression()
            self.expect(";", message="Expected ';' after print statement")
            return ("print", expr)
        if self.current()[0] == "IDENT":
            name = self.current()[1]
            self.pos += 1
            self.expect("=", message="Expected '=' in assignment")
            expr = self.expression()
            self.expect(";", message="Expected ';' at end of assignment")
            return ("assign", name, expr)
        got = self.current()[1] or "end of input"
        raise CompileError(f"Syntax Error: Expected let, print, or assignment; found {got!r}.")

    def expression(self):
        node = self.addition()
        if self.current()[1] in ("<", ">", "==", "!="):
            op = self.current()[1]
            self.pos += 1
            node = ("binary", op, node, self.addition())
        return node

    def addition(self):
        node = self.multiplication()
        while self.current()[1] in ("+", "-"):
            op = self.current()[1]
            self.pos += 1
            node = ("binary", op, node, self.multiplication())
        return node

    def multiplication(self):
        node = self.unary()
        while self.current()[1] in ("*", "/"):
            op = self.current()[1]
            self.pos += 1
            node = ("binary", op, node, self.unary())
        return node

    def unary(self):
        if self.current()[1] in ("+", "-"):
            op = self.current()[1]
            self.pos += 1
            return ("unary", op, self.unary())
        return self.primary()

    def primary(self):
        tok = self.accept(kind="NUMBER")
        if tok:
            value = float(tok[1]) if "." in tok[1] else int(tok[1])
            return ("number", value)
        tok = self.accept(kind="IDENT")
        if tok:
            return ("variable", tok[1])
        if self.accept("("):
            node = self.expression()
            self.expect(")", message="Expected ')'")
            return node
        got = self.current()[1] or "end of input"
        raise CompileError(f"Syntax Error: Expected a number, variable, or '('; found {got!r}.")

def analyze_and_run(ast):
    env = {}
    output = []
    tac = []
    temp_count = [0]

    def expr(node):
        kind = node[0]
        if kind == "number":
            return node[1], str(node[1])
        if kind == "variable":
            name = node[1]
            if name not in env:
                raise CompileError(f"Semantic Error: Variable '{name}' is used before declaration.")
            return env[name], name
        if kind == "unary":
            value, place = expr(node[2])
            result = +value if node[1] == "+" else -value
            temp_count[0] += 1
            temp = f"t{temp_count[0]}"
            tac.append(f"{temp} = {node[1]}{place}")
            return result, temp
        if kind == "binary":
            left, left_place = expr(node[2])
            right, right_place = expr(node[3])
            op = node[1]
            try:
                if op == "+": result = left + right
                elif op == "-": result = left - right
                elif op == "*": result = left * right
                elif op == "/":
                    if right == 0:
                        raise CompileError("Runtime Error: Division by zero.")
                    result = left / right
                elif op == "<": result = left < right
                elif op == ">": result = left > right
                elif op == "==": result = left == right
                elif op == "!=": result = left != right
                else: raise CompileError(f"Unsupported operator: {op}")
            except TypeError:
                raise CompileError("Semantic Error: Incompatible data types in expression.")
            temp_count[0] += 1
            temp = f"t{temp_count[0]}"
            tac.append(f"{temp} = {left_place} {op} {right_place}")
            return result, temp
        raise CompileError("Internal Error: Unknown expression node.")

    for stmt in ast[1]:
        if stmt[0] == "let":
            _, name, expression = stmt
            if name in env:
                raise CompileError(f"Semantic Error: Variable '{name}' is already declared.")
            value, place = expr(expression)
            env[name] = value
            tac.append(f"{name} = {place}")
        elif stmt[0] == "assign":
            _, name, expression = stmt
            if name not in env:
                raise CompileError(f"Semantic Error: Variable '{name}' is not declared.")
            value, place = expr(expression)
            env[name] = value
            tac.append(f"{name} = {place}")
        elif stmt[0] == "print":
            value, place = expr(stmt[1])
            output.append(str(value))
            tac.append(f"PRINT {place}")
    return output, tac, env

def generate_python(ast):
    lines = []
    for stmt in ast[1]:
        if stmt[0] == "let":
            lines.append(f"{stmt[1]} = {python_expr(stmt[2])}")
        elif stmt[0] == "assign":
            lines.append(f"{stmt[1]} = {python_expr(stmt[2])}")
        elif stmt[0] == "print":
            lines.append(f"print({python_expr(stmt[1])})")
    return "\n".join(lines)

def python_expr(node):
    if node[0] == "number": return repr(node[1])
    if node[0] == "variable": return node[1]
    if node[0] == "unary": return f"({node[1]}{python_expr(node[2])})"
    if node[0] == "binary": return f"({python_expr(node[2])} {node[1]} {python_expr(node[3])})"
    return ""

def compile_source(source):
    tokens = tokenize(source)
    ast = Parser(tokens).parse()
    output, tac, env = analyze_and_run(ast)
    generated = generate_python(ast)
    token_lines = [f"{kind:<9} {value}" for kind, value, _ in tokens if kind != "EOF"]
    return token_lines, tac, output, generated, env

class MiniCompilerApp:
    def __init__(self, root):
        self.root = root
        root.title("Mini Compiler - Compiler Design Project")
        root.geometry("1100x760")
        root.minsize(850, 600)
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        header = ttk.Frame(root, padding=12)
        header.pack(fill="x")
        ttk.Label(header, text="MINI COMPILER", font=("Segoe UI", 20, "bold")).pack(side="left")
        ttk.Label(header, text="Lexical • Syntax • Semantic • Intermediate Code • Execution",
                  font=("Segoe UI", 9)).pack(side="right")

        main = ttk.Panedwindow(root, orient="horizontal")
        main.pack(fill="both", expand=True, padx=12, pady=6)

        left = ttk.Frame(main, padding=6)
        right = ttk.Frame(main, padding=6)
        main.add(left, weight=1)
        main.add(right, weight=1)

        ttk.Label(left, text="Source Code", font=("Segoe UI", 12, "bold")).pack(anchor="w")
        self.editor = tk.Text(left, height=22, font=("Consolas", 12), wrap="none",
                              undo=True, bg="#171923", fg="#e6edf3", insertbackground="white",
                              padx=10, pady=10)
        self.editor.pack(fill="both", expand=True, pady=6)
        self.editor.insert("1.0", "let a = 10;\nlet b = 20;\nlet c = a + b * 2;\nprint c;\n")
        buttons = ttk.Frame(left)
        buttons.pack(fill="x", pady=4)
        ttk.Button(buttons, text="Compile & Run", command=self.compile).pack(side="left", padx=(0, 6))
        ttk.Button(buttons, text="Load Example", command=self.load_example).pack(side="left", padx=6)
        ttk.Button(buttons, text="Clear", command=self.clear).pack(side="left", padx=6)

        ttk.Label(right, text="Compiler Output", font=("Segoe UI", 12, "bold")).pack(anchor="w")
        self.output = tk.Text(right, height=22, font=("Consolas", 10), wrap="word",
                              bg="#f4f6f8", fg="#17202a", padx=10, pady=10, state="disabled")
        self.output.pack(fill="both", expand=True, pady=6)
        self.status = ttk.Label(root, text="Ready — enter a program and click Compile & Run.",
                                relief="sunken", anchor="w", padding=6)
        self.status.pack(fill="x", side="bottom")

    def show_output(self, text):
        self.output.config(state="normal")
        self.output.delete("1.0", "end")
        self.output.insert("1.0", text)
        self.output.config(state="disabled")

    def compile(self):
        source = self.editor.get("1.0", "end-1c")
        try:
            tokens, tac, result, generated, env = compile_source(source)
            sections = [
                "1. LEXICAL ANALYSIS — SUCCESS\n" + ("\n".join(tokens) or "(no tokens)"),
                "2. SYNTAX ANALYSIS — SUCCESS\nProgram grammar is valid.",
                "3. SEMANTIC ANALYSIS — SUCCESS\nVariables and expressions are valid.",
                "4. INTERMEDIATE CODE (THREE-ADDRESS CODE)\n" + ("\n".join(tac) or "(empty)"),
                "5. GENERATED PYTHON CODE\n" + (generated or "(empty)"),
                "6. PROGRAM OUTPUT\n" + ("\n".join(result) or "(no print output)"),
                "7. SYMBOL TABLE\n" + ("\n".join(f"{k} = {v} ({type(v).__name__})" for k, v in env.items()) or "(empty)")
            ]
            self.show_output("\n\n".join(sections))
            self.status.config(text="Compilation successful.")
        except CompileError as exc:
            self.show_output(str(exc))
            self.status.config(text="Compilation failed — see error details.")
        except Exception as exc:
            self.show_output(f"Unexpected Error: {exc}")
            self.status.config(text="Unexpected error.")

    def load_example(self):
        self.editor.delete("1.0", "end")
        self.editor.insert("1.0", "let a = 10;\nlet b = 20;\nlet c = a + b * 2;\nprint c;\n")

    def clear(self):
        self.editor.delete("1.0", "end")
        self.show_output("")
        self.status.config(text="Editor cleared.")

if __name__ == "__main__":
    root = tk.Tk()
    app = MiniCompilerApp(root)
    root.mainloop()
