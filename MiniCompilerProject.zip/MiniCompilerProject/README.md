# Mini Compiler — Compiler Design Project

A small educational compiler built with Python and Tkinter. It supports variable declarations, assignments, arithmetic expressions, comparisons, and print statements.

## Requirements
- Python 3.9 or newer
- Tkinter (usually included with standard Python installations)

## Run
```bash
python main.py
```

## Example program
```text
let a = 10;
let b = 20;
let c = a + b * 2;
print c;
```
Expected output: `50`

## Supported language
- `let name = expression;` — declare a variable
- `name = expression;` — update an existing variable
- `print expression;` — print a value
- Operators: `+ - * / < > == !=`
- Parentheses and unary `+` / `-`

## Compiler phases implemented
1. Lexical analysis: converts source text into tokens.
2. Syntax analysis: recursive-descent parser validates grammar and creates an AST.
3. Semantic analysis: checks declaration/use rules and duplicate declarations.
4. Intermediate code generation: emits three-address-style instructions.
5. Code generation: translates the AST into Python source.
6. Execution: evaluates the validated AST and displays program output.

## Notes
This is an educational mini-language, not a production compiler. The generated Python is displayed for learning; the app executes the parsed AST using its own evaluator.
